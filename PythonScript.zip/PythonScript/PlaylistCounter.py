import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from webdriver_manager.chrome import ChromeDriverManager

# Global Settigns
# ==========================
BasePlayList = "https://www.youtube.com/playlist?list=PLaOUGneDho1e68pM1WF_JJHw3T4mcPFsl"
SCROLL_PAUSE = 2
ACTION_DELAY = 1.0

# Sets Automation Profile Directory
# Enter the PATH for Storage Folder
USER_DATA_DIR = r"C:\Users\deiby\Desktop\Selenium-Profile"
PROFILE_DIRECTORY = "Default" 


# Sets Chrome Options
# ==========================
options = Options()
# Use Profile Persistently
options.add_argument(f"--user-data-dir={USER_DATA_DIR}")
options.add_argument(f"--profile-directory={PROFILE_DIRECTORY}")

# Remove Automation Flags
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option("useAutomationExtension", False)

# Init Driver
# Sets ChromeDriverManager
driver = webdriver.Chrome(
    service=Service(ChromeDriverManager().install()),
    options=options
)
driver.get(BasePlayList)
input("Log in manually if needed, then press ENTER here...")

# Scroll to load all videos
last_height = driver.execute_script("return document.documentElement.scrollHeight")

while True:
    driver.execute_script("window.scrollTo(0, document.documentElement.scrollHeight);")
    time.sleep(SCROLL_PAUSE)
    new_height = driver.execute_script("return document.documentElement.scrollHeight")
    if new_height == last_height:
        break
    last_height = new_height

print("Finished scrolling.")

# Scroll back to the top
time.sleep(ACTION_DELAY)
driver.execute_script("window.scrollTo(0, 0);")
print("Returned to START")

# Sets the Wait for the Driver
# Includes a Timeout
wait = WebDriverWait(driver, 10)

# Playlist Finder Funtion
# Saves the Videos into an Array of Selenium WebElement
def pFinder ():
    videos = driver.find_elements(By.TAG_NAME, "ytd-playlist-video-renderer")
    return videos

# Print the Video Count
ListGrab = pFinder()
VideoCount = len(ListGrab)
print(f"Total videos: {VideoCount}")

# Video Counter + Name
f_Path = "C:/Users/deiby/Downloads/PythonScript/PlaylistVideos.txt"
with open(f_Path, "w", encoding="utf-8") as file:
    for index, video in enumerate(ListGrab):
        # Get the Title
        title = video.find_element(By.ID, "video-title").text
        # Shows Current Video
        print("Video #" + str(index+1) + " " + title)
        file.write(title + "\n")

print("All done.")
driver.quit()