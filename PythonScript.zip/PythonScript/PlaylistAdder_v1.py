import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys

# Global Config
# ==========================
BasePlayList = "https://www.youtube.com/playlist?list=UUulFgkWSOzG3BOjSoPq1rXA"
SCROLL_PAUSE = 2
ACTION_DELAY = 1.0

# Sets Automation Profile Directoly
# Enter the PATH for Storage Folder
USER_DATA_DIR = r"C:\Users\deiby\Desktop\Selenium-Profile"
PROFILE_DIRECTORY = "Default" 


# Sets Chrome Options
# ==========================
options = Options()
# Use Profile Persistently
options.add_argument(f"--user-data-dir={USER_DATA_DIR}")
options.add_argument(f"--profile-directory={PROFILE_DIRECTORY}")

# Remove Automation Flags
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option("useAutomationExtension", False)

# Init Driver
# Sets ChromeDriverManager
driver = webdriver.Chrome(
    service=Service(ChromeDriverManager().install()),
    options=options
)
driver.get(BasePlayList)
input("Log in manually if needed, then press ENTER here...")

# Scroll to load all videos
last_height = driver.execute_script("return document.documentElement.scrollHeight")

while True:
    driver.execute_script("window.scrollTo(0, document.documentElement.scrollHeight);")
    time.sleep(SCROLL_PAUSE)
    new_height = driver.execute_script("return document.documentElement.scrollHeight")
    if new_height == last_height:
        break
    last_height = new_height

print("Finished scrolling.")

# Scroll back to the top
time.sleep(ACTION_DELAY)
driver.execute_script("window.scrollTo(0, 0);")
print("Returned to START")

# Sets the Wait for the Driver
# Includes a Timeout
wait = WebDriverWait(driver, 10)

# Playlist Finder Funtion
# Saves the Videos into an Array of Selenium WebElement
def pFinder ():
    videos = driver.find_elements(By.TAG_NAME, "ytd-playlist-video-renderer")
    return videos

# Saves the Videos into an Array of Selenium WebElement
# videos = driver.find_elements(By.TAG_NAME, "ytd-playlist-video-renderer")

# Print the Video Count
ListGrab = pFinder ()
VideoCount = len(ListGrab)
print(f"Total videos: {VideoCount}")

# Playlist Siffter
def PlaylistAdder (video):
    # Waits on 3-Dot Menu visibility
    menu_button = wait.until(
        # Wait until Clickable
        EC.element_to_be_clickable(
            video.find_element(By.CSS_SELECTOR, "button[aria-label='Action menu']")
        )
    )
    # Clicks the Button
    ActionChains(driver).move_to_element(menu_button).click().perform()


    # Waits on Popup visibility
    menu_popup = wait.until(
        # Wait until Clickable
        EC.element_to_be_clickable((By.CSS_SELECTOR, "ytd-menu-popup-renderer"))
    )
    # Saves Popup xPath
    p_Path = '//*[@id="items"]/ytd-menu-navigation-item-renderer/a/tp-yt-paper-item'
    # Search for "Save playlist"  
    mItem = menu_popup.find_element(
        By.XPATH,
        f'{p_Path}[normalize-space()="Save to playlist"]'
    )
    # Click on Option
    ActionChains(driver).move_to_element(mItem).click().perform()

    # Wait on PopupList visibility
    wait.until(
        EC.visibility_of_element_located((By.CSS_SELECTOR, "yt-list-item-view-model"))
    )

    # Wait until Options Exist
    wait.until (
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, "span.yt-list-item-view-model__title"))
    )

    # Wait until Playlist Options are Present
    # Search Value "Aux-V123" by xPATH
    item = wait.until(
        EC.presence_of_element_located((
            By.XPATH,
            "//span[contains(@class,'yt-list-item-view-model__title') and contains(.,'Aux-V123')]"
        ))
    )
    # Wait to Click
    time.sleep(ACTION_DELAY)
    # Click on Target Playlist
    driver.execute_script("arguments[0].click();", item)

# Run through the Video Array
for index, video in enumerate(ListGrab):
    # Scroll to Current Video
    driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", video)
    print("Opening Menu for Video #: " + str(index+1))
    # Wait to Load
    time.sleep(ACTION_DELAY)
    # Call to Function
    PlaylistAdder(video)

print("All done.")
driver.quit()